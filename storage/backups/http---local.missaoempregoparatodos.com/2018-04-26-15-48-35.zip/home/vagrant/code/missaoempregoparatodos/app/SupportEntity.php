<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupportEntity extends Model
{
    //
}
